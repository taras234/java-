public class MainApp {

    public static void main(String[] args) {

        ZiffernRaten5 ziffernRaten = new ZiffernRaten5();
        ziffernRaten.run();

    }

}

